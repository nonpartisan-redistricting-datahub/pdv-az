This file was obtained via OpenPrecincts.org and is licensed in the public domain.

az_2018.cpg
    - Hope Johnson


az_2018.dbf
    - Hope Johnson


az_2018.prj
    - Hope Johnson


az_2018.sbn
    - Hope Johnson


az_2018.sbx
    - Hope Johnson


az_2018.shp
    - Hope Johnson


az_2018.shx
    - Hope Johnson



