This file was obtained via OpenPrecincts.org and is licensed in the public domain.

az_2016.cpg
    - Hope Johnson

 -  
az_2016.dbf
    - Hope Johnson

 -  
az_2016.prj
    - Hope Johnson

 -  
az_2016.sbn
    - Hope Johnson

 -  
az_2016.sbx
    - Hope Johnson

 -  
az_2016.shp
    - Hope Johnson

 -  
az_2016.shx
    - Hope Johnson

 -  

